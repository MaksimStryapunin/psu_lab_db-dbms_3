create function return_next_value(table_name text, column_name text) returns integer
    language plpgsql
as
$$
DECLARE
    max_value integer;
    id integer;
BEGIN

END;
$$;

alter function return_next_value(text, text) owner to postgres;

